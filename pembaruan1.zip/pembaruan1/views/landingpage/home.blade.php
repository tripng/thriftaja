@extends('landingpage.index')
@section('content')
    @include('landingpage.rekomendasi')
    @include('barang.product')
    @include('landingpage.sale')
@endsection
