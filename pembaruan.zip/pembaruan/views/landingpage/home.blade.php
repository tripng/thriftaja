@extends('landingpage.index')
@section('content')
    @include('landingpage.rekomendasi')
    @include('landingpage.product')
    @include('landingpage.sale')
@endsection
