
    <div class="hero__slider owl-carousel">
        <div class="container">
            <div class="row">
                <div class="col-xl-5 col-lg-5 col-md-5 mt-5">
                    <div class="hero__text mt-5">
                        <h6>Summer Collection</h6>
                        <h4>ELECTRONIC COLLECTION 2022</h4>
                        <p>Lorem ipsum is simply dummi text of the printting and type setting
                            industry, lorem ipsum has been the.</p>
                        <a href="#" class="primary-btn">Shop now <span class="arrow_right"></span></a>
                    </div>
                </div>
                <div class="col-xl-5 col-lg-5 col-md-5 mt-5">
                    <img src="img/projek/l1.jpg" class="card-img-top" alt="...">
                </div>
            </div>
        </div>
    </div>
    <div class="row col-sm-12 mt-5 mb-2">
        <div class="rounded mx-auto d-block">
            <h4 class="font-weight-bold"> ELECTRONIC</h4>
            <h4 class="font-weight-bold"> COLLECTION 2022</h4>
        </div>
    </div>
    <div class="row w-100 mt-5 mx-auto d-flex justify-content-around">
        <div class="col-sm-6">
            <div class="card d-block mx-auto" style="width: 18rem;">
                <img src="img/projek/phone.jpg" class="card-img-top" alt="...">
                <div class="card-body">
                    <p class="card-text">Handphone Collection 2022</p>
                </div>
            </div>
        </div>
        <div class="col-sm-6 ">
            <div class="card d-block mx-auto" style="width: 18rem;">
                <img src="img/projek/l2.jpg" class="card-img-top" alt="...">
                <div class="card-body">
                    <p class="card-text">Handphone Collection 2022</p>
                </div>
            </div>
        </div>
    </div>
