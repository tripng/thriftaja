<header class="header bg-f1f1f1">
       <div class="container">
        <div class="row">
            <div class="col-lg-2 col-md-2">
                <div class="header__logo">
                    <a href="#"><img src="img/thriftaja.png" alt=""></a>
                </div>
            </div>
            <div class="col-lg-4 col-md-4">
                <nav class="header__menu mobile-menu">
                    <ul>
                        </li>
                        <li class="active"><a href="{{ url('/home') }}">Home</a></li>
                        <li ><a href="{{ url('/shop') }}">Shop</a></li>
                    </ul>
                </nav>
            </div>
            <div class="col-lg-6 col-md-4">
                <div class="header__nav__option">
                    <a href="#" class="search-switch"><form class="d-flex" role="search">
                        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                        <button class="btn btn-outline-success" type="submit"><img src="img/icon/search.png" alt=""></button>
                    </form></a>
                    <a href="#"><img src="img/icon/heart.png" alt=""></a>
                    <a href="./shopping-cart.html"><img src="img/icon/cart.png" alt=""> <span>0</span></a>
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><img src="img/icon/person-circle.svg" alt=""></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="{{ url('/login') }}">Login/Registrasi</a></li>
                        <li><a class="dropdown-item" href="#">profile</a></li>
                        <li><a class="dropdown-item" href="#!">Settings</a></li>
                        <li><a class="dropdown-item" href="#">Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</header>

